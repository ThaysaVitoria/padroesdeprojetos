﻿using solucao1.domains;

try
{
    Console.WriteLine("---------------pedido 01--------");
    Pedido pedido new= new Pedido();
    pedido.sucessoAoPagar();
    pedido.despacharPedido();

    Console.WriteLine("--------------pedido 02---------");
    Pedido pedido2 new = new Pedido();
    pedido2.sucessoAoPagar();
    pedido2.despacharPedido();
    pedido2.cancelarPedido();

} catch(Exception e)
{
    Console.WriteLine(e.Message);
        }