﻿//cria lista e matriz 

using Iterator.IteratorModel;

List<int> lista = [1, 2, 3, 4, 5, 6, 7, 8, 9];
List<List<int>> matriz = [[1, 2, 3], [4, 5, 6], [7, 8, 9]];

//criar o iterator
IteratorInterface listaIterator = new ListaIterator(lista);
IteratorInterface matrizIterator = new MatrizIterator(matriz);

//iterar sobre a lista
Console.WriteLine("Lista - Vetor");
ImpressoraDeAgregados.iterar(listaIterator);

//iterar sobre a matriz
Console.WriteLine("Matriz");
ImpressoraDeAgregados.iterar(matrizIterator);
