﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Iterator.IteratorModel
{
    public class ListaIterator : IteratorInterface
    {
        private List<int> lista = new List<int>();
        private int indice { get; set; } = 0;
        private int tamanho { get; set; }

        public ListaIterator(List<int> lista)
        {
            this.lista = lista;
            this.tamanho = lista.Count();
        }

        public bool hasNext(){
            if (this.indice >= this.tamanho)
            {
                return false;
            }
            return true;
        }
        public int next(){
            int item = this.lista[this.indice];
            this.indice += 1;
            return item;
        }
    }
}
