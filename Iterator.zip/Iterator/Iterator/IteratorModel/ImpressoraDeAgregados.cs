﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator.IteratorModel
{
    public class ImpressoraDeAgregados
    {
        public static void iterar(IteratorInterface iterator)
        {
            while (iterator.hasNext())
            {
                Console.WriteLine(iterator.next() + "  ");
            }
        }
    }
}
