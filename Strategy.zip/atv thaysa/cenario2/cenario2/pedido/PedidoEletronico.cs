﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cenario2.pedido
{
    internal class PedidoEletronico:Pedido
    {
     public PedidoEletronico()
        {
            this.nomeSetor = "Eletronicos";
        }        

    }
}
