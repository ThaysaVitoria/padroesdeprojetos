﻿using cenario2.pedido;

Pedido pedidoEletro = new PedidoEletronico();

pedidoEletro.valor = 100;

Console.WriteLine("Frete Comum:" + pedidoEletro.nomeSetor + "R$" + pedidoEletro.calculaFreteComum());

Console.WriteLine("Frete Expresso:" + pedidoEletro.nomeSetor+"R$" + pedidoEletro.calculaFreteExpresso());