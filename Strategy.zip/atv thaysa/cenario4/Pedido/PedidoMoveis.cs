﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cenario4.Pedido
{
    public class PedidoMoveis:Pedido
    {
        public PedidoMoveis() {
            this.nomeSetor = "Moveis";
        }

       
    }
}
